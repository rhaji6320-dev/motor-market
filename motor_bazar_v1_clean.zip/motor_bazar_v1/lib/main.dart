import 'package:flutter/material.dart';

void main() => runApp(const MotorBazarApp());

class MotorBazarApp extends StatelessWidget {
  const MotorBazarApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'موتر بازار',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final cars = const [
    Car('Toyota Corolla', '2015', '120,000 km', '450,000 افغانی', 'کابل'),
    Car('Toyota Camry', '2018', '85,000 km', '780,000 افغانی', 'کابل'),
    Car('Honda Civic', '2017', '95,000 km', '560,000 افغانی', 'هرات'),
    Car('Toyota Prado', '2014', '145,000 km', '1,250,000 افغانی', 'کابل'),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('موتر بازار',
              style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          ],
        ),
        body: index == 0
            ? HomeContent(cars: cars)
            : index == 1
                ? const AddListingPage()
                : const ProfilePage(),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home),
                label: 'خانه'),
            NavigationDestination(
                icon: Icon(Icons.add_circle_outline),
                selectedIcon: Icon(Icons.add_circle),
                label: 'ثبت آگهی'),
            NavigationDestination(
                icon: Icon(Icons.person_outline),
                selectedIcon: Icon(Icons.person),
                label: 'حساب'),
          ],
        ),
      ),
    );
  }
}

class HomeContent extends StatelessWidget {
  final List<Car> cars;
  const HomeContent({super.key, required this.cars});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              color: Theme.of(context).colorScheme.primaryContainer,
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('موتر مورد نظرت را پیدا کن',
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('آگهی‌های موترهای دست‌دوم در افغانستان'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const TextField(
            decoration: InputDecoration(
              hintText: 'برند، مدل یا شهر را جستجو کن',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(16)),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _FilterButton('برند', Icons.directions_car)),
              const SizedBox(width: 8),
              Expanded(child: _FilterButton('شهر', Icons.location_on_outlined)),
              const SizedBox(width: 8),
              Expanded(child: _FilterButton('فیلتر', Icons.tune)),
            ],
          ),
          const SizedBox(height: 22),
          const Text('آگهی‌های جدید',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ...cars.map((c) => CarCard(car: c)),
        ],
      );
}

class _FilterButton extends StatelessWidget {
  final String text;
  final IconData icon;
  const _FilterButton(this.text, this.icon);

  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
        onPressed: () {},
        icon: Icon(icon, size: 18),
        label: Text(text),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      );
}

class Car {
  final String name, year, km, price, city;
  const Car(this.name, this.year, this.km, this.price, this.city);
}

class CarCard extends StatelessWidget {
  final Car car;
  const CarCard({super.key, required this.car});

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => CarDetailPage(car: car)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Container(
                  width: 105,
                  height: 90,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  ),
                  child: const Icon(Icons.directions_car, size: 48),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(car.name,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 5),
                      Text('${car.year}  •  ${car.km}'),
                      const SizedBox(height: 5),
                      Text(car.price,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color:
                                  Theme.of(context).colorScheme.primary)),
                      Text(car.city),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_left),
              ],
            ),
          ),
        ),
      );
}

class CarDetailPage extends StatelessWidget {
  final Car car;
  const CarDetailPage({super.key, required this.car});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('جزئیات آگهی')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              height: 230,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
              ),
              child: const Icon(Icons.directions_car, size: 100),
            ),
            const SizedBox(height: 18),
            Text(car.name,
                style:
                    const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(car.price,
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.primary)),
            const Divider(height: 30),
            _InfoRow('سال', car.year),
            _InfoRow('کارکرد', car.km),
            _InfoRow('موقعیت', car.city),
            const SizedBox(height: 24),
            FilledButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.phone),
                label: const Text('تماس با فروشنده')),
            const SizedBox(height: 10),
            OutlinedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.chat),
                label: const Text('واتساپ')),
          ],
        ),
      );
}

class _InfoRow extends StatelessWidget {
  final String title, value;
  const _InfoRow(this.title, this.value);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title),
            Text(value,
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      );
}

class AddListingPage extends StatelessWidget {
  const AddListingPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('ثبت آگهی موتر',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          _field('برند و مدل', Icons.directions_car),
          _field('سال ساخت', Icons.calendar_today),
          _field('کارکرد (کیلومتر)', Icons.speed),
          _field('قیمت (افغانی)', Icons.payments_outlined),
          _field('شهر', Icons.location_on_outlined),
          _field('شماره تماس', Icons.phone),
          OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('افزودن عکس')),
          const SizedBox(height: 16),
          FilledButton(onPressed: () {}, child: const Text('ثبت آگهی')),
        ],
      );

  Widget _field(String label, IconData icon) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: Icon(icon),
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const CircleAvatar(
              radius: 42, child: Icon(Icons.person, size: 45)),
          const SizedBox(height: 12),
          const Center(
              child: Text('حساب من',
                  style: TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold))),
          const SizedBox(height: 24),
          Card(
              child: ListTile(
                  leading: const Icon(Icons.favorite),
                  title: const Text('علاقه‌مندی‌ها'),
                  onTap: () {})),
          Card(
              child: ListTile(
                  leading: const Icon(Icons.list_alt),
                  title: const Text('آگهی‌های من'),
                  onTap: () {})),
          Card(
              child: ListTile(
                  leading: const Icon(Icons.report_outlined),
                  title: const Text('گزارش مشکل'),
                  onTap: () {})),
        ],
      );
}
