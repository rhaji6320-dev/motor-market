import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  final db = Supabase.instance.client;
  bool loading = true;
  List<Map<String, dynamic>> cars = [];
  List<Map<String, dynamic>> reports = [];

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final c = await db
          .from('cars')
          .select()
          .eq('status', 'pending')
          .order('created_at', ascending: false);
      final r = await db
          .from('reports')
          .select('id,car_id,reason,status,created_at')
          .eq('status', 'open')
          .order('created_at', ascending: false);

      if (!mounted) return;
      setState(() {
        cars = List<Map<String, dynamic>>.from(c);
        reports = List<Map<String, dynamic>>.from(r);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('دسترسی مدیر لازم است: $e')),
      );
    }
  }

  Future<void> review(String id, String status) async {
    await db
        .from('cars')
        .update({'status': status, 'featured': false})
        .eq('id', id);
    await load();
  }

  Future<void> closeReport(String id) async {
    await db.from('reports').update({'status': 'closed'}).eq('id', id);
    await load();
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('پنل مدیریت'),
        actions: [
          IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(12),
              children: [
                Text(
                  'اعلان‌های در انتظار (${cars.length})',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                ...cars.map(
                  (x) => Card(
                    child: ListTile(
                      title: Text('${x['brand']} ${x['model']}'),
                      subtitle: Text('${x['price'] ?? '-'} • ${x['city'] ?? '-'}'),
                      trailing: SizedBox(
                        width: 150,
                        child: Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () => review('${x['id']}', 'rejected'),
                                child: const Text('رد'),
                              ),
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: FilledButton(
                                onPressed: () => review('${x['id']}', 'approved'),
                                child: const Text('تأیید'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const Divider(height: 32),
                Text(
                  'گزارش‌ها (${reports.length})',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                ...reports.map(
                  (r) => Card(
                    child: ListTile(
                      title: Text('${r['reason']}'),
                      subtitle: Text('Car: ${r['car_id']}'),
                      trailing: IconButton(
                        onPressed: () => closeReport('${r['id']}'),
                        icon: const Icon(Icons.check),
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
