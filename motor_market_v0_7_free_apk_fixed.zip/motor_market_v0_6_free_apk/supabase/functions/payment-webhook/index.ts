// v0.5 webhook boundary. Verify provider signature before changing payment status.
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', {status:405});
  // TODO: verify webhook signature and atomically update public.payments.
  return new Response(JSON.stringify({ok:false,message:'Webhook provider not connected yet'}), {headers:{'content-type':'application/json'},status:501});
});
