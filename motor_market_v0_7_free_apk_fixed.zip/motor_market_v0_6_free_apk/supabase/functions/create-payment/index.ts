// v0.5 payment boundary. Never put provider secret keys in Flutter.
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', {status:405});
  // TODO: verify Supabase JWT, validate car/amount, call the selected Afghan payment provider.
  return new Response(JSON.stringify({ok:false,message:'Payment provider not connected yet'}), {headers:{'content-type':'application/json'},status:501});
});
