import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/car.dart';
import '../services/backend.dart';
import 'admin_page.dart';
import 'add_listing_page.dart';
import 'car_detail_page.dart';
import 'login_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController q = TextEditingController();
  String city = '';
  String brand = '';
  Future<List<Car>>? future;
  bool admin = false;
  int tab = 0;

  @override
  void initState() {
    super.initState();
    future = Backend.cars();
    _checkAdmin();
  }

  @override
  void dispose() {
    q.dispose();
    super.dispose();
  }

  Future<void> _checkAdmin() async {
    if (!Supabase.instance.isInitialized) return;
    if (Supabase.instance.client.auth.currentUser == null) return;

    final value = await Backend.isAdmin();
    if (mounted) {
      setState(() => admin = value);
    }
  }

  void search() {
    setState(() {
      future = Backend.cars(
        q: q.text,
        city: city,
        brand: brand,
      );
    });
  }

  Future<void> filters() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (ctx, setSheetState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'فیلتر جستجو',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 18),
                  DropdownButtonFormField<String>(
                    value: brand.isEmpty ? null : brand,
                    decoration: const InputDecoration(
                      labelText: 'برند',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      'Toyota',
                      'Honda',
                      'Hyundai',
                      'Kia',
                      'Nissan',
                      'Mercedes',
                    ].map((x) {
                      return DropdownMenuItem<String>(
                        value: x,
                        child: Text(x),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setSheetState(() => brand = value ?? '');
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    decoration: const InputDecoration(
                      labelText: 'شهر',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (value) {
                      setSheetState(() => city = value);
                    },
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        Navigator.pop(ctx);
                        search();
                      },
                      child: const Text('اعمال فیلتر'),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final Widget body = tab == 0
        ? _home()
        : const Center(
            child: Text(
              'بخش علاقه‌مندی‌ها در نسخه بعدی با صفحه اختصاصی تکمیل می‌شود',
            ),
          );

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Icon(
              Icons.directions_car_rounded,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(width: 8),
            const Text(
              'موتر بازار',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
          ],
        ),
        actions: [
          if (admin)
            IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AdminPage(),
                  ),
                );
              },
              icon: const Icon(Icons.admin_panel_settings_outlined),
            ),
          IconButton(
            onPressed: () async {
              await showDialog<void>(
                context: context,
                builder: (_) => const LoginPage(),
              );
              _checkAdmin();
            },
            icon: const Icon(Icons.person_outline),
          ),
        ],
      ),
      body: body,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (index) => setState(() => tab = index),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'خانه',
          ),
          NavigationDestination(
            icon: Icon(Icons.favorite_border),
            selectedIcon: Icon(Icons.favorite),
            label: 'علاقه‌مندی',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const AddListingPage(),
            ),
          ).then((_) => search());
        },
        icon: const Icon(Icons.add),
        label: const Text('فروش موتر'),
      ),
    );
  }

  Widget _home() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Column(
            children: [
              const Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'موتر مناسب خود را پیدا کن',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: q,
                      onSubmitted: (_) => search(),
                      decoration: const InputDecoration(
                        hintText: 'برند یا مدل...',
                        prefixIcon: Icon(Icons.search),
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: filters,
                    icon: const Icon(Icons.tune),
                  ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Car>>(
            future: future,
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }

              if (snapshot.hasError) {
                return Center(child: Text('خطا: ${snapshot.error}'));
              }

              final cars = snapshot.data ?? <Car>[];
              if (cars.isEmpty) {
                return const Center(child: Text('فعلاً اعلانی پیدا نشد'));
              }

              return RefreshIndicator(
                onRefresh: () async => search(),
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 90),
                  itemCount: cars.length,
                  itemBuilder: (context, index) => _card(cars[index]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _card(Car car) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CarDetailPage(car: car),
            ),
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                SizedBox(
                  height: 190,
                  width: double.infinity,
                  child: car.photos.isNotEmpty
                      ? Image.network(
                          car.photos.first,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Icon(
                            Icons.directions_car,
                            size: 70,
                          ),
                        )
                      : Container(
                          color: Colors.black12,
                          child: const Icon(
                            Icons.directions_car,
                            size: 70,
                          ),
                        ),
                ),
                if (car.featured)
                  const Positioned(
                    top: 12,
                    right: 12,
                    child: Chip(
                      avatar: Icon(Icons.star, size: 16),
                      label: Text('ویژه'),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${car.brand} ${car.model}',
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text('${car.year}  •  ${car.city}'),
                  const SizedBox(height: 8),
                  Text(
                    '${car.price} افغانی',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
