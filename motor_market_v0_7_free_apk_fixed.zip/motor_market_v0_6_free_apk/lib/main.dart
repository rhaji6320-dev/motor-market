import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/home_page.dart';
import 'screens/login_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (url.isNotEmpty && key.isNotEmpty) {
    await Supabase.initialize(url: url, publishableKey: key);
  }
  runApp(const MotorMarketApp());
}

class MotorMarketApp extends StatelessWidget {
  const MotorMarketApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'موتر بازار',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo, scaffoldBackgroundColor: const Color(0xFFF7F8FC)),
    home: Supabase.instance.isInitialized ? const HomePage() : const SetupPage(),
  );
}

class SetupPage extends StatelessWidget {
  const SetupPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, shape: BoxShape.circle), child: const Icon(Icons.directions_car_rounded, size: 64)),
      const SizedBox(height: 20), const Text('موتر بازار', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10), const Text('نسخه 0.5 • بازار خرید و فروش موترهای دست‌دوم', textAlign: TextAlign.center),
      const SizedBox(height: 20), const Text('برای اجرای نسخه آنلاین، SUPABASE_URL و SUPABASE_PUBLISHABLE_KEY را هنگام build تنظیم کنید.', textAlign: TextAlign.center),
    ])),
  );
}
