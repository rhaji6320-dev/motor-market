class Car {
  final String id, sellerId, brand, model, city, phone, description;
  final int year;
  final num price;
  final List<String> photos;
  final bool featured;
  Car({required this.id, required this.sellerId, required this.brand, required this.model, required this.year, required this.price, required this.city, required this.phone, required this.description, required this.photos, required this.featured});
  factory Car.fromMap(Map<String,dynamic> m) => Car(id:'${m['id']}', sellerId:'${m['seller_id'] ?? ''}', brand:'${m['brand'] ?? ''}', model:'${m['model'] ?? ''}', year:(m['year'] as num?)?.toInt() ?? 0, price:m['price'] as num? ?? 0, city:'${m['city'] ?? ''}', phone:'${m['phone'] ?? ''}', description:'${m['description'] ?? ''}', photos:List<String>.from(m['photos'] ?? const []), featured:m['featured'] == true);
}
