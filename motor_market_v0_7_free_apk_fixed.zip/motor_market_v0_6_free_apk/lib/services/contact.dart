import 'package:url_launcher/url_launcher.dart';
class ContactService {
  static Future<void> call(String phone) async { final u=Uri.parse('tel:$phone'); if(await canLaunchUrl(u)) await launchUrl(u); }
  static Future<void> whatsapp(String phone) async { final clean=phone.replaceAll(RegExp(r'[^0-9]'),''); final u=Uri.parse('https://wa.me/$clean'); if(await canLaunchUrl(u)) await launchUrl(u,mode:LaunchMode.externalApplication); }
}
