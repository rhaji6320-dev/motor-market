import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/car.dart';
class Backend {
  static final sb = Supabase.instance.client;
  static String? get uid => sb.auth.currentUser?.id;
  static Future<List<Car>> cars({String q='', String city='', String brand='', bool featuredOnly=false}) async {
    var query = sb.from('cars').select().eq('status','approved');
    if (city.isNotEmpty) query = query.eq('city', city);
    if (brand.isNotEmpty) query = query.eq('brand', brand);
    if (featuredOnly) query = query.eq('featured', true);
    if (q.trim().isNotEmpty) query = query.or('brand.ilike.%${q.trim()}%,model.ilike.%${q.trim()}%');
    final rows = await query.order('featured', ascending:false).order('created_at', ascending:false);
    return (rows as List).map((e)=>Car.fromMap(Map<String,dynamic>.from(e))).toList();
  }
  static Future<String> uploadPhoto(Uint8List bytes, String path) async {
    await sb.storage.from('car-photos').uploadBinary(path, bytes, fileOptions: const FileOptions(upsert:false));
    return sb.storage.from('car-photos').getPublicUrl(path);
  }
  static Future<void> createCar(Map<String,dynamic> data) async => sb.from('cars').insert(data);
  static Future<void> report(String carId, String reason) async => sb.from('reports').insert({'car_id':carId,'reporter_id':uid,'reason':reason});
  static Future<bool> isFavorite(String carId) async { if(uid==null) return false; final r=await sb.from('favorites').select('car_id').eq('user_id',uid!).eq('car_id',carId).maybeSingle(); return r!=null; }
  static Future<void> toggleFavorite(String carId) async { if(uid==null) return; final exists=await isFavorite(carId); if(exists){await sb.from('favorites').delete().eq('user_id',uid!).eq('car_id',carId);}else{await sb.from('favorites').insert({'user_id':uid,'car_id':carId});} }
  static Future<bool> isAdmin() async { if(uid==null) return false; final r=await sb.rpc('is_admin'); return r == true; }
}
