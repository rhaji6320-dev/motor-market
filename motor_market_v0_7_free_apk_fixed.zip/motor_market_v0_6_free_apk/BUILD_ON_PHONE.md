# ساخت APK با گوشی — کاملاً آنلاین

این پروژه برای ساخت APK با GitHub Actions آماده شده است؛ نیازی به نصب Flutter یا Android Studio روی گوشی نیست.

## مراحل

1. در GitHub یک حساب بسازید یا وارد شوید.
2. یک Repository جدید بسازید؛ بهتر است Private باشد.
3. فایل‌های این پروژه را داخل Repository آپلود کنید.
4. از تب **Actions**، workflow با نام **Build Android APK** را باز کنید.
5. روی **Run workflow** بزنید.
6. بعد از تمام شدن Build، وارد اجرای موفق workflow شوید.
7. در بخش **Artifacts** فایل `motor-bazar-apk` را دریافت کنید.
8. فایل APK را روی گوشی نصب کنید.

## نکته مهم

این workflow برای نسخه تستی APK است. برای انتشار رسمی در Google Play باید بعداً APK/AAB را با کلید امضای اختصاصی خودمان Sign کنیم.

## Supabase

اگر می‌خواهید نسخه آنلاین دیتابیس داشته باشد، هنگام Build می‌توانیم URL و Publishable Key را بعداً به‌صورت GitHub Secrets اضافه کنیم. کلیدهای محرمانه سروری را هرگز داخل اپ قرار ندهید.
